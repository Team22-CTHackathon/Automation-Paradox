import re
import csv
#//input[@name='input']
#//input[@name='login']


def keyforxpath(fxpath):
    matchgroup = re.match(r"//(\w+)\[@\w+='(\w+)'\]",fxpath)
    return(matchgroup.group(1)+'_'+ matchgroup.group(2))

filestring={}
xpath = "//input[@name='login']"
key = keyforxpath(xpath)
print('Key- %s' %(key))
filestring[key] = xpath

w= csv.writer(open("output.csv","w"))
for key, val in filestring.items():
    w.writerow([key,val])

