
import csv
import os
import re
import shutil
from selenium import webdriver
from scrapper import Scrapper
from Readingpropertiesfile import readproperty
from xpathfile import Xpath_Util
from webdriver_manager.microsoft import IEDriverManager

class XpathFileFeeder:

    def __init__(self):
        self.path='D:\\propertiesFile'
        self.filenametext=''
        self.input_file = ''
        self.output_file=''
        self.dat=''
        self.writer=''
        self.specialscurlystart = '{'
        self.specialscurlyclose = '}'
        self.specialquotestart = '\''
        self.specialcoloncharacter = ':'
        self.list = ['id', 'name', 'classname']
        self.listforpropertiesfile =[]
        self.propertiespath1= 'C:/Users/Team22Admin/PycharmProjects/Newxpath/sample.properties'
        self.propertiespath2= 'C:/Users/Team22Admin/PycharmProjects/Newxpath/new.properties'
        # propertiesfile = 'C:/Users/Team22Admin/PycharmProjects/Newxpath/sample.properties'
        # newpropertiesfile = 'C:/Users/Team22Admin/PycharmProjects/Newxpath/new.properties'

    def check(self, attr):
        # list1 = ['id', 'name', 'classname']

        if attr in self.list:
            return True
        else:
            return False

    def xpath_file_feeder_main(self):

        for filename in os.listdir(self.path):
            self.input_file = open(os.path.join(self.path,filename), 'r')
            self.data = csv.reader(self.input_file)
            self.filenametext = filename.split(".")[0]
            self.output_file = open(os.path.join(self.path,self.filenametext+"."+"txt"),'w')
            self.writer = csv.writer(self.output_file)
            for line in self.data:

                line = [value.replace(self.specialscurlystart, '') for value in line]
                line = [value.replace(self.specialscurlyclose, '') for value in line]
                line = [value.replace(self.specialquotestart, '') for value in line]

                if any(field.strip() for field in line):
                    self.writer.writerow(line)

            self.input_file.close()
            self.output_file.close()

    def xpath_file_feeder_print_lines(self):

            filename=os.listdir(self.path)
            print(filename)
            files_txt = [i for i in filename if i.endswith('.txt')]
            # print(files_txt)
            for textfile in files_txt:

                textfilenmwoext=textfile.split(".")
                f = open(os.path.join(self.path,textfile), 'r')
                line = f.readline()
                # use the read line to read further.
                # If the file is not empty keep reading one line
                # at a time, till the file is empty
                # if any(field.strip() for field in line):
                while line:
                    get_out=False
                    # to read line
                    # print line
                    # in pythonprint is a builtin function, so
                    words = line.split(",")
                    for word in words:
                        if(get_out):
                            break
                        word = word.replace(" ","")
                        keywords=word.split(":")
                        for keyword in keywords:
                            if(get_out):
                                break
                            if self.check(keyword):
                                print(keywords[0],keywords[1])
                                xpath = "//%s[@%s='%s']" % (textfilenmwoext[0], keywords[0], keywords[1])
                                self.listforpropertiesfile.append(xpath)
                                print(xpath)
                                get_out=True
                                break
                            else:
                                break

                    line = f.readline()
                f.close()
            print(self.listforpropertiesfile)
            # return self.listforpropertiesfile
    def propertiespath1(self):
        return self.propertiespath1(self)
    def propertiespath2(self):
        return self.propertiespath2(self)

    def key(line3):
        words = line3.split(",")
        for word in words:
            print(word)

    def perform_deletion(self):

        # folder = '/path/to/folder'
        shutil.rmtree(self.path)
        for the_file in os.listdir(self.path):
            file_path = os.path.join(self.path, the_file)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
                # elif os.path.isdir(file_path): shutil.rmtree(file_path)
            except Exception as e:
                print(e)

    def finalkey_Xpath_Listgeneration(self):
        keylist = []
        for il in self.listforpropertiesfile:
            words = re.split('\W', il)
            print(words)
            key = "%s_%s" % (words[2], words[6])
            keylist.append(key)

        final_dict = dict(zip(keylist, self.listforpropertiesfile))
        print(final_dict)
        return final_dict

# -------START OF SCRIPT--------
if __name__ == "__main__":
    try:
        scrapper_obj = Scrapper()
        scrapper_obj.generate_propertiescsv()
        xpathfilefeeder_obj = XpathFileFeeder()
        xpathfilefeeder_obj.xpath_file_feeder_main()
        xpathfilefeeder_obj.xpath_file_feeder_print_lines()
        xpath_Util_obj = Xpath_Util()
        driver = xpath_Util_obj.open_webpage()
        Webelementspresence = xpath_Util_obj.verify_xpath(xpathfilefeeder_obj.listforpropertiesfile)
        print("The webelements presence check is",Webelementspresence)
        xpath_Util_obj.close_webpage()
        finallist=xpathfilefeeder_obj.finalkey_Xpath_Listgeneration()
        print("the final list is")
        print(finallist)
        rpfile_obj = readproperty()
        rpfile_obj.finalPropertiesfileGeneration(finallist)

    except Exception as e:
        print(e)
        print(e.__class__)