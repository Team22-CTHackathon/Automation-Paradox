import re
import os
import csv
class readproperty:

    def __init__(self):
        self.propertiesfile = 'C:/Users/Team22Admin/Downloads/POM_Framework/src/citiustech/hackaton/resources/locator.properties'
        self.newpropertiesfile = 'C:/Users/Team22Admin/PycharmProjects/Newxpath/new.properties'
        self.comparelistofxpath ={'Input_Name': "//input[@id='name']", 'input_login': "//input[@name='login']",'input_name2$31': "//input[@name='name2$31']"}

    def finalPropertiesfileGeneration(self,list):
        li=[]
        self.comparelistofxpath =list
        lines = []
        replacements = {'//Following list includes xpaths for newly exposed objects on UIList:': ''}
        with open(self.propertiesfile) as infile:
            for line in infile:
                for src, target in replacements.items():
                    line = line.replace(src, target)
                lines.append(line)
        with open(self.propertiesfile, 'w') as outfile:
            for line in lines:
                if line.rstrip():
                    outfile.write(line)
        f = open(self.propertiesfile,"r")
        contents = f.readlines()
        listofkeysxpath ={}
        compproperty,comppgenerate= '',''
        finallistofkeyspath={}
        excludedlistofkeypath ={}
        #storing the contents of file in a dictionary for processing
        for line in contents:
            matchgroup = re.match(r"^(\S+)=\w+\|(.+)", line)
            listofkeysxpath[matchgroup.group(1)]= matchgroup.group(2)
        print("Existing property-%s"%(listofkeysxpath))
        print("CSV generted-%s"%(self.comparelistofxpath))
        for propertykey in listofkeysxpath:
            for generatedkey in self.comparelistofxpath:
                compgenerate = re.sub(r"([a-zA-z_]+).{0,}",r"\1",generatedkey)
                compproperty = re.sub(r"([a-zA-z_]+).{0,}", r"\1", propertykey)
                if((generatedkey in propertykey) or (propertykey in generatedkey) or (compgenerate in compproperty) ):
                    finallistofkeyspath[propertykey]=self.comparelistofxpath[generatedkey]
                    break
                else:
                    excludedlistofkeypath[generatedkey]=self.comparelistofxpath[generatedkey]

        for generatedkey in excludedlistofkeypath.copy():
            for propertykey in finallistofkeyspath:
                if (generatedkey in propertykey):
                    excludedlistofkeypath.pop(generatedkey, None)

        print("finallly-%s" %(finallistofkeyspath))
        print("Excluded List-%s" % (excludedlistofkeypath))
        # w=open("new.properties","w")
        # for key, val in finallistofkeyspath.items():
        #     w.writelines("%s=xpath|%s\n"%(key,val))
        # w.close();f.close()
        if os.path.getsize(self.propertiesfile)==0:
            w = open("new.properties", "w")
            for key, val in self.comparelistofxpath.items():
                w.writelines("%s=xpath|%s\n" % (key, val))
            w.close();
            f.close()
        else:
            w = open("new.properties", "w")
            for key, val in finallistofkeyspath.items():
                w.writelines("%s=xpath|%s\n" % (key, val))
            w.writelines("//Following list includes xpaths for newly exposed objects on UI")
            w.writelines("List:\n")
            for key, val in excludedlistofkeypath.items():
                w.writelines("%s=xpath|%s\n" % (key, val))
            w.close();
            f.close()
        os.replace(self.newpropertiesfile,self.propertiesfile)

    # -------START OF SCRIPT--------
if __name__ == "__main__":
    print("Start of %s" % __file__)

    # Initialize the xpath object
    RP_obj = readproperty()
    RP_obj.finalPropertiesfileGeneration()