import requests
from bs4 import BeautifulSoup
import sys
import csv
import optparse
import datetime

class Scrapper:

    def __init__(self):
        #self.page = requests.get("http://localhost")
        self.page = requests.get("http://localhost")
        self.managable_tags = ['a', 'button', 'input', 'radio', 'select', 'email']  # tags

    def generate_propertiescsv(self):

        self.page
        self.page.status_code
        # page.content
        soup = BeautifulSoup(self.page.content, 'html.parser')
        # print(soup.prettify())

        soup = BeautifulSoup(self.page.content, 'html.parser')
        print(soup.find_all('input'))

      # attributes_dictionary = soup.find('input').attrs
      # print (attributes_dictionary)

        for tag in soup.find_all('input'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/input.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()
        for tag in soup.find_all('select'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/select.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()
        for tag in soup.find_all('a'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/a.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()
        for tag in soup.find_all('button'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/button.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()
        for tag in soup.find_all('radio'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/radio.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()
        for tag in soup.find_all('email'):
          typo_attributes_dictionary = tag.attrs
          print(typo_attributes_dictionary)
          f = open("D:/propertiesFile/email.csv", 'a')
          # sys.stdout = f
          print(typo_attributes_dictionary, file=f)
          # f.write(typo_attributes_dictionary)
          f.close()


# for tag in soup.find_all("meta"):
#     tag.get()
#     if tag.get("property", None) == "og:title":
#         print tag.get("content", None)
#     elif tag.get("property", None) == "og:url":
#         print tag.get("content", None)
# -------START OF SCRIPT--------
if __name__ == "__main__":
     Scrapper_obj = Scrapper()
     Scrapper_obj.generate_propertiescsv()